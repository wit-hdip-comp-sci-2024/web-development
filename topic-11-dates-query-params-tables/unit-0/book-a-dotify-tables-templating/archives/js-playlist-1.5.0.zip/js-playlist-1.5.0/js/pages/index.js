document.addEventListener('DOMContentLoaded', () => {
  const main = document.querySelector('main');
  dotify.dataStore.list().forEach((playlist) => {
    main.innerHTML = main.innerHTML + dotify.components.createPlaylistItem(playlist);
  });
});